<?php
session_start();
$conn = mysqli_connect("localhost", "root", "","bd_auto");
if (!$conn) {
    echo("Deu ruim!!");
}
echo("Conexão criada com sucesso!!");


$email = $_POST["email"];
$senha = $_POST["senha"];

$sql = "SELECT user,id FROM usuario WHERE email = '$email' AND senha = '$senha'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_array($result);
    $_SESSION['user'] = $row['user'];
    $_SESSION['id'] = $row['id'];

    header('Location: https://localhost/ProjetoPHP/Projeto_v1.2/index.php');
} else {
    echo("Email ou senha inválidos!!");
    header('Location: https://localhost/ProjetoPHP/Projeto_v1.2/login.php');
}
?>