<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "bd_auto");

// Pegando os dados do cadastrar.php / ta pegando pela tag "name="""
$cpf = trim($_POST['cpf']);
$nome = trim($_POST['nome']);
$endereco = trim($_POST['endereco']);
$telefone = trim($_POST['telefone']);
$email = trim($_POST['email']);
$user = trim($_POST['user']);
$senha = trim($_POST['senha']);

// Construindo o comando SQL
$sql = "INSERT INTO usuario 
        (cpf, nome, endereco, telefone, email, user, senha) 
        VALUES 
        ('$cpf', '$nome', '$endereco', '$telefone', '$email', '$user', '$senha')";

$result = $conn->query($sql);

// mensagem de sucesso ou erro
if ($result) {
    echo '<script>alert("Cliente cadastrado com sucesso!!");</script>';
    header("Refresh: 0; https://localhost/ProjetoPHP/Projeto_v1.2/login.php");               
} else {
    echo '<script>alert("Erro ao cadastrar cliente!");</script>';
    header("Refresh: 0; https://localhost/ProjetoPHP/Projeto_v1.2/cadastrar.php");
}

?>