<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de cliente</title>
    <link rel="stylesheet" href="./css/cadastro.css">
</head>

<body>
    <header class="header">
        <div class="headerContainer">
            <div class="headerLogo">
                <a href="index.php"><img src="./imagens/logo.png" alt="Logo"></a>
            </div>
            <nav class="nav">
                <ul class="navUl">
                    <a href="./contato.php">
                        <li class="navLi">Contato</li>
                    </a>
                    <a href="./info.php">
                        <li class="navLi">Ajuda</li>
                    </a>
                    <a href="./minhasReservas.php">
                        <li class="navLi">Minhas reservas</li>
                    </a>
                    <a href="login.php">
                        <li class="navLi">Login</li>
                    </a>
                    <a href="./cadastrar.php">
                        <li class="navLi">Cadastro</li>
                    </a>
                    <a href="index.php">
                        <li class="navLi">Voltar</li>
                    </a>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">
        <section class="test">
            <h2>Cadastro</h2>
        </section>
        <form class="form" method="POST" action="cadastro.php">
            <fieldset class="form-content">
                <label for="username">User name:</label>
                <input type="text" id="username" name="user">
                <label for="name">Seu Nome:</label>
                <input type="text" id="name" name="nome">
                <label for="cpf">Seu CPF:</label>
                <input type="text" id="cpf" name="cpf">
                <label for="email">Seu E-mail:</label>
                <input type="email" id="email" name="email">
                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco">
                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone">
                <label for="password">Senha:</label>
                <input type="password" id="password" name="senha">
                <button type="submit">Cadastrar</button>
            </fieldset>
        </form>
    </div>
</body>

</html>