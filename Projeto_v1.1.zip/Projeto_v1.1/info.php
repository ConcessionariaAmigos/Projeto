<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/info.css">
    <title>Informações</title>
</head>
<body> 
    <div class="headerContainer">
        <h1>Informações sobre o site:</h1>
        <a href="index.php" class="btnVoltar">Voltar</a>
    </div>
    <ul id="button">
        <button onclick="mudarConteudo()">Sobre o Aluguel</button>
        <button onclick="mudarConteudo2()">Fornecedor</button>
    </ul>
    <div id="Info" class="hidden">
    </div>
    <div class="img">
        <img src="./imagens/info.webp" alt="mclarensenna">
    </div>
</body>
<script src="js/info.js"></script>
</html>