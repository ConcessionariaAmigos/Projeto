<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "bd_auto");

$carro = trim($_POST['carro']);
$localDeRetirada = trim($_POST['localDeRetirada']);
$localDeDevolucao = trim($_POST['localDeDevolucao']);
$diaDeRetirada = trim($_POST['diaDeRetirada']);
$diaDeDevolucao = trim($_POST['diaDeDevolucao']);
$diaria = trim($_POST['diaria']);

$sql = "INSERT INTO aluguelCarro 
        (carro, localDeRetirada, localDeDevolucao, diaDeRetirada, diaDeDevolucao, diaria) 
        VALUES 
        ('$carro', '$localDeRetirada', '$localDeDevolucao', '$diaDeRetirada', '$diaDeDevolucao', '$diaria')";

$result = $conn->query($sql);

if ($result) {
    echo '<script>alert("Carro Alugado com Sucesso!!");</script>';
    header("Refresh: 0; http://localhost/ProjetoPHP/Projeto_v2.1/minhasReservas.php");               
} else {
    echo '<script>alert("Erro ao Alugar o Carro!");</script>';
    header("Refresh: 0; http://localhost/ProjetoPHP/Projeto_v2.1/pagamento.php");
}
