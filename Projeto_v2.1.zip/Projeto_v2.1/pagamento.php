<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "bd_auto");

// Pegando os dados do pagar.php / ta pegando pela tag "name="""
$localDeRetirada = trim($_POST['localDeRetirada']);
$localDeDevolucao = trim($_POST['localDeDevolucao']);
$diaDeRetirada = trim($_POST['diaDeRetirada']);
$diaDeDevolucao = trim($_POST['diaDeDevolucao']);
$diaria = trim($_POST['diaria']);

// Construindo o comando SQL
$sql = "INSERT INTO aluguelCarro 
        (localDeRetirada, localDeDevolucao, diaDeRetirada, diaDeDevolucao, diaria) 
        VALUES 
        ('$localDeRetirada', '$localDeDevolucao', '$diaDeRetirada', '$diaDeDevolucao', '$diaria')";

$result = $conn->query($sql);

if ($result) {
    echo '<script>alert("Carro Alugado com Sucesso!!");</script>';
    header("Refresh: 0; http://localhost/ProjetoPHP/Projeto_v2.0/minhasReservas.php");               
} else {
    echo '<script>alert("Erro ao Alugar o Carro!");</script>';
    header("Refresh: 0; http://localhost/ProjetoPHP/Projeto_v2.0/pagamento.php");
}
