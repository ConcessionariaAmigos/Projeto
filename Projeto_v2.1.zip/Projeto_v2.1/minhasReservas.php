<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>minhas Reservas</title>
    <link rel="stylesheet" href="./css/reservas.css">
</head>
<body>
    <header class="header">
        <div class="headerContainer">
            <div class="headerLogo">
                <a href=""><img src="./imagens/logo.png" alt="Logo"></a>
            </div>
            <nav class="nav">
                <ul class="navUl">
                    <a href="./contato.php" target="_blanck"><li class="navLi">Contato</li></a>
                    <a href="./info.php"><li class="navLi">Ajuda</li></a>
                    <a href="./minhasReservas.php"><li class="navLi">Minhas reservas</li></a>
                    <?php
                    if(isset($_SESSION['user'])){
                        echo '<li class="navLi">' . $_SESSION['user'] . '</li>';
                        echo '<a href="logoff.php"><li class="navLi">Sair</li></a>';
                    }else{
                    ?>
                    <a href="login.php"><li class="navLi">Login</li></a>
                    <a href="./cadastrar.php"><li class="navLi">Cadastro</li></a>
                    <?php
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <section class="section">
        <table class="table">
            <tr class="tableRow">
                <th class="tableTitle">id</th>
                <th class="tableTitle">Local de Retirada</th>
                <th class="tableTitle">Local de Devolução</th>
                <th class="tableTitle">Data de Retirada</th>
                <th class="tableTitle">Data de Devolução</th>
                <th class="tableTitle">Diária</th>
            </tr>
            <tr class="tableRow">
                <td class="tableContent">.</td>
                <td class="tableContent">.</td>
                <td class="tableContent">.</td>
                <td class="tableContent">.</td>
                <td class="tableContent">.</td>
                <td class="tableContent">.</td>
            </tr>   
        </table>
    </section>
</body>
</html>