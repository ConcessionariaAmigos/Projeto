fetch("../listarReservas.php") // Fernando: Não sei se o link do listarReservas.php está correto, teoricamente está, os dois pontos leva o caminho pra raíz da pasta onde está o listarReservas.php
.then(resposta => resposta.json())
.then(console.log(resposta)) // Fernando: Coloquei esse console pra ver se aparecia algo, e não apareceu nada, nem mesmo uma mensagem de erro.
.catch(console.error("Não carrega!")); // Fernando: Não aparece nada