<?php

session_start();

$conn = mysqli_connect("localhost", "root", "","bd_auto");

if (!$conn) {
    echo("Deu ruim!!"); // Fernando: Tentei usar a conexão que eu fiz no "logar.php", não apareceu a mensagem "Deu ruim!!"
}
echo("Conexão criada com sucesso!!"); // Fernando: Mas também não apareceu a mensagem da conexão criada com sucesso.
    
$sql = "SELECT * FROM aluguelcarro"; // Fernando: Lá no phpMyAdmin o nome da tabela tá com o c minúsculo, mas lá no "pagamento.php" tá com C maiúsculo e tá funcionando, eu tentei das duas maneiras, mas nenhuma deu certo.

$result = mysqli_query($conn, $sql);

if($result -> num_rows > 0){ // Fernando: Mantive essa parte igual o da professora, se está retornando algo era pra ser aqui. tentei dar um echo no $data pra ver se aparece algo.
    $data = array();
    echo $data; // Fernando: Não apareceu nada pra mim. Acho que o erro está pra cima.
    while($row = $result -> fetch_assoc()){
        $data[] = $row;
        echo $data;
        echo '<script>alert("Carro Alugado com Sucesso!!");</script>';
    }
        echo json_encode($data);
    }

?>

