<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/info.css">
    <title>Informações</title>
</head>
<body> 
    <div class="headerContainer">
        <h1>Informações sobre o site:</h1>
        <a href="javascript:history.back()" class="btnVoltar">Voltar</a>
    </div>
    <ul id="button">
        <button id="about">Sobre o Aluguel</button>
        <button id="supplier">Fornecedor</button>
    </ul>
    <div class="infoContent">
        <div id="aboutContent" class="hidden">
            <p>O que preciso para alugar um carro?<br>
            Ter idade mínima de 21 anos;<br>
            Clientes com idade superior a 21 anos poderão efetuar a locação mediante o pagamento de taxa adicional denominada Locação Jovem;<br>
            Locatário: Apresentar Carteira de Habilitação (CNH) definitiva, original e válida;<br>
            Apresentar cartão de crédito, com emissão bancária, com chip e bandeira e limite disponível para pré-autorização, em nome do locatário ou responsável financeiro;<br>
            Não possuir restrições financeiras ou de qualquer espécie;<br>
            O Responsável Financeiro deverá estar presente no momento da abertura do contrato portando CPF e RG original, e não possuir restrições de qualquer espécie."
        </p>
        </div>
        <div id="supplierContent" class="hidden">
            <p>
            Como ser um fornecedor da Road?<br>
            Para se cadastrar e ser um de nossos fornecedores, pedimos que seja encaminhado um e-mail para fornecedores@roadfrotas.com.br ou realizado o contato através do telefone 0800 728 5808 (opção 1), horário de segunda a sexta-feira das 08h às 18h.
            </p>
        </div>
    </div>
</body>
<script src="js/info.js"></script>
</html>