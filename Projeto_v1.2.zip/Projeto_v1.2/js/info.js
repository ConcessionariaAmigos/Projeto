function mudarConteudo(){
  var infoDiv = document.getElementById("Info");
  document.getElementById("Info").innerHTML = "O que preciso para alugar um carro? <br> Ter idade mínima de 21 anos; <br>  Clientes com idade superior a 19 anos e inferior a 21 anos poderão efetuar a locação mediante o pagamento de taxa adicional denominada Locação Jovem; <br> Locatário: Apresentar Carteira de Habilitação (CNH) definitiva, original e válida; <br> Apresentar cartão de crédito, com emissão bancária, com chip e bandeira e limite disponível para pré-autorização, em nome do locatário ou responsável financeiro; <br>  Não possuir restrições financeiras ou de qualquer espécie; <br> O Responsável Financeiro deverá estar presente no momento da abertura do contrato portando CPF e RG original, e não possuir restrições de qualquer espécie.";
  infoDiv.classList.remove("hidden");
}
  
function mudarConteudo2(){
  var infoDiv = document.getElementById("Info");
  document.getElementById("Info").innerHTML = "Como ser um fornecedor da Movida? <br> Para se cadastrar e ser um de nossos fornecedores, pedimos que seja encaminhado um e-mail para fornecedores@roadfrotas.com.br ou realizado o contato através do telefone 0800 728 5808 (opção 1), horário de segunda a sexta-feira das 08h às 18h.";
  infoDiv.classList.remove("hidden");
}