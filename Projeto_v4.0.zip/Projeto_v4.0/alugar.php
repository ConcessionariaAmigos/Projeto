<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Reservas</title>
    <link rel="stylesheet" href="./css/alugar.css">
</head>

<body>
    <header class="header">
        <div class="headerContainer">
            <div class="headerLogo">
                <a href=""><img src="./imagens/logo.png" alt="Logo"></a>
            </div>
            <nav class="nav">
                <ul class="navUl">
                    <a href="./contato.php" target=_blank><li class="navLi">Contato</li></a>
                    <a href="./info.php"><li class="navLi">Ajuda</li></a>
                    <a href="./minhasReservas.php"><li class="navLi">Minhas reservas</li></a>
                    <a href="./login.php"><li class="navLi">Login</li></a>
                    <a href="./cadastrar.php"><li class="navLi">Cadastro</li></a>
                </ul>
            </nav>
        </div>
    </header>
    <section class="mainContent">
        <div class="formContainer">
            <form class="form">
                <fieldset class="fieldset">
                    <h3 class="h3">SEU ITINERÁRIO</h3>
                    <label for="" class="marca">Local de Retirada*:</label>
                    <input type="text" class="cpf" placeholder="Onde você quer alugar">
                    <label for="" class="modelo">Local de Devolução*:</label>
                    <input type="text" class="password" placeholder="Onde você quer alugar">
                    <a href="produtos.php" class="btnConsult">
                        Reservar
                    </a>
                </fieldset>
            </form>
        </div>
    </section>
</body>

</html>